#include <ql/qldefines.hpp>
#if !defined(BOOST_ALL_NO_LIB) && defined(BOOST_MSVC)
#  include <ql/auto_link.hpp>
#endif

#include <ql/instruments/vanillaoption.hpp>
#include <ql/pricingengines/vanilla/analyticeuropeanengine.hpp>
#include <ql/pricingengines/vanilla/binomialengine.hpp>
#include <ql/pricingengines/vanilla/fdblackscholesvanillaengine.hpp>
#include <ql/time/calendars/china.hpp>
#include <ql/time/daycounters/actual360.hpp>
#include <ql/utilities/dataformatters.hpp>

#include <iostream>
#include <iomanip>

using namespace QuantLib;

int main(int, char* [])
{
    std::cout << std::endl;

    // set up dates
    Calendar calendar = China();
    Date todaysDate(24, March, 2023);
    Date settlementDate(24, March, 2023);
    Settings::instance().evaluationDate() = todaysDate;

    // our options
    Option::Type type(Option::Put);
    Real underlying = 4027.05;
    Real strike = 4000;
    Spread dividendYield = 0.0218;
    Rate riskFreeRate = 0.025407;
    Volatility volatility = 0.20;
    Date maturity(15, September, 2023);
    DayCounter dayCounter = Actual360();

    std::cout << "Option type = " << type << std::endl;
    std::cout << "Maturity = " << maturity << std::endl;
    std::cout << "Underlying price = " << underlying << std::endl;
    std::cout << "Strike = " << strike << std::endl;
    std::cout << "Risk-free interest rate = " << io::rate(riskFreeRate) << std::endl;
    std::cout << "Dividend yield = " << io::rate(dividendYield) << std::endl;
    std::cout << "Volatility = " << io::volatility(volatility) << std::endl;
    std::cout << std::endl;

    std::string method;
    std::cout << std::endl;

    // write column headings
    Size widths[] = { 35, 14, 14, 14 };
    std::cout << std::setw(widths[0]) << std::left << "Method"
        << std::setw(widths[1]) << std::left << "European"
        << std::endl;

    auto europeanExercise = ext::make_shared<EuropeanExercise>(maturity);
    auto underlyingH = makeQuoteHandle(underlying);

    // bootstrap the yield/dividend/vol curves
    Handle<YieldTermStructure> flatTermStructure(
        ext::make_shared<FlatForward>(settlementDate, riskFreeRate, dayCounter));
    Handle<YieldTermStructure> flatDividendTS(
        ext::make_shared<FlatForward>(settlementDate, dividendYield, dayCounter));
    Handle<BlackVolTermStructure> flatVolTS(
        ext::make_shared<BlackConstantVol>(settlementDate, calendar, volatility, dayCounter));
    
    auto payoff = ext::make_shared<PlainVanillaPayoff>(type, strike);
    
    auto bsmProcess = ext::make_shared<BlackScholesMertonProcess>(
        underlyingH, flatDividendTS, flatTermStructure, flatVolTS);

    // options
    VanillaOption europeanOption(payoff, europeanExercise);
 
    // Analytic formulas    
    // Black-Scholes for European
    method = "Black-Scholes";
    europeanOption.setPricingEngine(ext::make_shared<AnalyticEuropeanEngine>(bsmProcess));
    std::cout << std::setw(widths[0]) << std::left << method
        << std::fixed
        << std::setw(widths[1]) << std::left << europeanOption.NPV()
        << std::endl;

    // Finite differences
    Size timeSteps = 801;
    method = "Finite differences";
    auto fdengine =
        ext::make_shared<FdBlackScholesVanillaEngine>(bsmProcess,
            timeSteps,
            timeSteps - 1);
    europeanOption.setPricingEngine(fdengine);
    std::cout << std::setw(widths[0]) << std::left << method
        << std::fixed
        << std::setw(widths[1]) << std::left << europeanOption.NPV()
        << std::endl;

    // Binomial method: Cox-Ross-Rubinstein
    method = "Binomial Cox-Ross-Rubinstein";
    auto crrEngine = 
        ext::make_shared<BinomialVanillaEngine<CoxRossRubinstein>>(bsmProcess, timeSteps);
    europeanOption.setPricingEngine(crrEngine);
    std::cout << std::setw(widths[0]) << std::left << method
        << std::fixed
        << std::setw(widths[1]) << std::left << europeanOption.NPV()
        << std::endl;

    //========================= Greeks Calculation with Analytic Engine ==================
    europeanOption.setPricingEngine(ext::make_shared<AnalyticEuropeanEngine>(bsmProcess));

    std::cout << std::endl;
    // write column headings
    Size widths2[] = { 14, 14, 14, 14, 14, 14, 14 };
    std::cout << std::setw(widths2[0]) << std::left << "Greeks"
        << std::setw(widths2[1]) << std::left << "Delta"
        << std::setw(widths2[2]) << std::left << "Gamma"
        << std::setw(widths2[3]) << std::left << "Vega"
        << std::setw(widths2[4]) << std::left << "Theta"
        << std::setw(widths2[5]) << std::left << "Rho"
        << std::setw(widths2[6]) << std::left << "RhoOfYield"
        << std::endl;

    double Delta = europeanOption.delta();
    double Gamma = europeanOption.gamma();
    double Vega = europeanOption.vega();
    double Theta = europeanOption.theta();
    double Rho = europeanOption.rho();
    double DivRho = europeanOption.dividendRho();

    std::cout << std::setw(widths2[0]) << std::left << ""
        << std::setw(widths2[1]) << std::left << Delta
        << std::setw(widths2[2]) << std::left << Gamma
        << std::setw(widths2[3]) << std::left << Vega
        << std::setw(widths2[4]) << std::left << Theta
        << std::setw(widths2[5]) << std::left << Rho
        << std::setw(widths2[6]) << std::left << DivRho
        << std::endl;

    //============================= Implied Volatility Calculation =======================
    europeanOption.setPricingEngine(ext::make_shared<AnalyticEuropeanEngine>(bsmProcess));

    std::cout << std::endl;
    // write column headings
    Size widths3[] = { 14, 14, 14 };
    std::cout << std::setw(widths3[0]) << std::left << "Implied Vol"
        << std::setw(widths3[1]) << std::left << "Price"
        << std::setw(widths3[2]) << std::left << "Volatility"
        << std::endl;

    double Price1 = 180.0;
    double impVol1 = europeanOption.impliedVolatility(Price1, bsmProcess);

    std::cout << std::setw(widths3[0]) << std::left << ""
        << std::setw(widths3[1]) << std::left << Price1
        << std::setw(widths3[2]) << std::left << impVol1
        << std::endl;


    double Price2 = 220.0;
    double impVol2 = europeanOption.impliedVolatility(Price2, bsmProcess);

    std::cout << std::setw(widths3[0]) << std::left << ""
        << std::setw(widths3[1]) << std::left << Price2
        << std::setw(widths3[2]) << std::left << impVol2
        << std::endl;

    // End test
    return 0;
}
